/*
 * @file  pvmnet.h
 * @author vgusev
 *
 * Copyright (C) 1999-2016 Parallels International GmbH.
 * All Rights Reserved.
 * http://www.parallels.com
 */

#include "OEMNetInterface.h"
#include "ApiNet.h"
